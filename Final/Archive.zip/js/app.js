
var currentTextIndex = 1;

function toggleText() {
    // Find the currently visible container
    var visibleContainer = document.querySelector('.container:not([style*="none"])');

    // If there is a visible container, hide it
    if (visibleContainer) {
      visibleContainer.style.display = 'none';
    }

    // Find the next container to display
    var nextContainer = visibleContainer ? visibleContainer.nextElementSibling : document.querySelector('.container');

    // If there is a next container, display it
    if (nextContainer) {
      nextContainer.style.display = 'flex';
    }
}


